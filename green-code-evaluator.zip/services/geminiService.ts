
import { GoogleGenAI, Type } from "@google/genai";
import type { AnalysisResult, OptimizationResult, QuizQuestion } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const parseJsonResponse = <T,>(text: string): T | null => {
    try {
        const cleanedText = text.replace(/^```json\s*|```\s*$/g, '').trim();
        return JSON.parse(cleanedText) as T;
    } catch (error) {
        console.error("Failed to parse JSON response:", error);
        return null;
    }
}

export const analyzeCode = async (code: string, language: string): Promise<AnalysisResult | null> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `As an expert in green software engineering, analyze the following ${language} code snippet for its potential carbon footprint. Consider factors like algorithmic complexity (Big O notation), potential CPU cycles, memory usage, and I/O operations. Provide an estimated carbon emission in grams of CO2e (Carbon Dioxide Equivalent) and a detailed, constructive explanation for your estimation. Respond in JSON format.\n\nCode:\n\`\`\`${language}\n${code}\n\`\`\``,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        co2e: { type: Type.NUMBER, description: "Estimated CO2e in grams." },
                        explanation: { type: Type.STRING, description: "Detailed explanation of the carbon footprint estimation." }
                    },
                    required: ["co2e", "explanation"]
                }
            }
        });
        const resultText = response.text;
        return parseJsonResponse<AnalysisResult>(resultText);
    } catch (error) {
        console.error("Error analyzing code:", error);
        return null;
    }
};

export const optimizeCode = async (code: string, language: string): Promise<OptimizationResult | null> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Given the following ${language} code, rewrite it to be more energy-efficient and reduce its carbon footprint. Focus on improving algorithmic efficiency, reducing unnecessary computations, and optimizing memory usage. Provide the optimized code and a brief explanation of the improvements made. Respond in JSON format.\n\nCode:\n\`\`\`${language}\n${code}\n\`\`\``,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        optimizedCode: { type: Type.STRING, description: "The optimized, more energy-efficient code." },
                        explanation: { type: Type.STRING, description: "Explanation of the optimizations made." }
                    },
                    required: ["optimizedCode", "explanation"]
                }
            }
        });
        const resultText = response.text;
        return parseJsonResponse<OptimizationResult>(resultText);
    } catch (error) {
        console.error("Error optimizing code:", error);
        return null;
    }
};


export const getEducationalContent = async (): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Generate a concise and informative article about 'Sustainable Software Development Taxonomies'. The target audience is software developers. Cover key concepts like the Green Software Foundation's taxonomy, explain why it's important, and provide actionable tips for developers to write greener code. Structure the content with clear headings and paragraphs. Use Markdown for formatting.`,
            config: {
                systemInstruction: "You are an expert educator in sustainable software engineering."
            }
        });
        return response.text;
    } catch (error) {
        console.error("Error fetching educational content:", error);
        return "Failed to load educational content. Please try again later.";
    }
};

export const generateQuiz = async (): Promise<QuizQuestion[]> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Generate a 5-question multiple-choice quiz about global sustainability goals, carbon emissions, and green software development. For each question, provide the question text, 4 options (one of which is correct), and the index of the correct answer (0-3).`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            question: { type: Type.STRING },
                            options: {
                                type: Type.ARRAY,
                                items: { type: Type.STRING }
                            },
                            correctAnswerIndex: { type: Type.INTEGER }
                        },
                        required: ["question", "options", "correctAnswerIndex"]
                    }
                }
            }
        });
        const resultText = response.text;
        const parsed = parseJsonResponse<QuizQuestion[]>(resultText);
        return parsed || [];
    } catch (error) {
        console.error("Error generating quiz:", error);
        return [];
    }
};
