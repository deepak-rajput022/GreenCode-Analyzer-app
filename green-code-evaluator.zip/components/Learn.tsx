
import React, { useState, useEffect } from 'react';
import { getEducationalContent } from '../services/geminiService';
import { Spinner } from './shared/Spinner';

const Learn: React.FC = () => {
  const [content, setContent] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchContent = async () => {
      setIsLoading(true);
      const educationalContent = await getEducationalContent();
      // A simple markdown-to-html conversion for display
      const formattedContent = educationalContent
        .replace(/## (.*)/g, '<h2 class="text-2xl font-bold text-green-400 mt-6 mb-3">$1</h2>')
        .replace(/### (.*)/g, '<h3 class="text-xl font-semibold text-green-300 mt-4 mb-2">$1</h3>')
        .replace(/\* \*(.*?)\* \*/g, '<strong>$1</strong>')
        .replace(/\n/g, '<br />');
      setContent(formattedContent);
      setIsLoading(false);
    };

    fetchContent();
  }, []);

  return (
    <div className="max-w-4xl mx-auto bg-gray-800 p-6 sm:p-8 rounded-lg shadow-xl">
      <h1 className="text-3xl font-bold text-center mb-6 text-green-400">
        Learn About Sustainable Software
      </h1>
      {isLoading ? (
        <div className="flex justify-center items-center py-20">
            <div className="text-center">
                <Spinner />
                <p className="mt-2 text-gray-400">Loading educational content...</p>
            </div>
        </div>
      ) : (
        <div
          className="prose prose-invert max-w-none text-gray-300 leading-relaxed"
          dangerouslySetInnerHTML={{ __html: content }}
        />
      )}
    </div>
  );
};

export default Learn;
