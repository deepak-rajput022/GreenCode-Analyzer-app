
import React, { useState, useEffect, useCallback } from 'react';
import { generateQuiz } from '../services/geminiService';
import type { QuizQuestion } from '../types';
import { Spinner } from './shared/Spinner';

const Quiz: React.FC = () => {
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState<number>(0);
  const [quizFinished, setQuizFinished] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);

  const fetchQuiz = useCallback(async () => {
    setIsLoading(true);
    setQuizFinished(false);
    setCurrentQuestionIndex(0);
    setScore(0);
    setSelectedAnswer(null);
    setIsAnswered(false);
    const quizQuestions = await generateQuiz();
    setQuestions(quizQuestions);
    setIsLoading(false);
  }, []);

  useEffect(() => {
    fetchQuiz();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleAnswerSelect = (answerIndex: number) => {
    if (isAnswered) return;
    setSelectedAnswer(answerIndex);
    setIsAnswered(true);
    if (answerIndex === questions[currentQuestionIndex].correctAnswerIndex) {
      setScore(score + 1);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(null);
      setIsAnswered(false);
    } else {
      setQuizFinished(true);
    }
  };

  if (isLoading) {
    return (
        <div className="flex justify-center items-center py-20">
            <div className="text-center">
                <Spinner />
                <p className="mt-2 text-gray-400">Generating your quiz...</p>
            </div>
        </div>
    );
  }

  if (questions.length === 0) {
    return <div className="text-center text-gray-400">Failed to load quiz. Please try again.</div>;
  }

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <div className="max-w-2xl mx-auto bg-gray-800 p-6 sm:p-8 rounded-lg shadow-xl">
      <h1 className="text-3xl font-bold text-center mb-6 text-green-400">Sustainability Quiz</h1>

      {quizFinished ? (
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">Quiz Complete!</h2>
          <p className="text-xl mb-6">
            Your score: <span className="font-bold text-green-400">{score}</span> out of {questions.length}
          </p>
          <button
            onClick={fetchQuiz}
            className="px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-green-500"
          >
            Play Again
          </button>
        </div>
      ) : (
        <div>
          <div className="mb-4">
            <p className="text-gray-400">Question {currentQuestionIndex + 1} of {questions.length}</p>
            <h2 className="text-xl font-semibold mt-1">{currentQuestion.question}</h2>
          </div>
          <div className="space-y-3">
            {currentQuestion.options.map((option, index) => {
              const isCorrect = index === currentQuestion.correctAnswerIndex;
              const isSelected = selectedAnswer === index;
              let buttonClass = 'w-full text-left p-4 rounded-lg border-2 border-gray-600 hover:bg-gray-700 transition-colors duration-200';
              if (isAnswered) {
                if (isCorrect) {
                  buttonClass += ' bg-green-800 border-green-500';
                } else if (isSelected) {
                  buttonClass += ' bg-red-800 border-red-500';
                }
              }
              return (
                <button
                  key={index}
                  onClick={() => handleAnswerSelect(index)}
                  disabled={isAnswered}
                  className={buttonClass}
                >
                  {option}
                </button>
              );
            })}
          </div>
          {isAnswered && (
             <button
                onClick={handleNextQuestion}
                className="mt-6 w-full px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-green-500"
              >
                {currentQuestionIndex < questions.length - 1 ? 'Next Question' : 'Finish Quiz'}
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default Quiz;
