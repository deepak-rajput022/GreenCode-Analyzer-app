
import React, { useState, useCallback } from 'react';
import { analyzeCode, optimizeCode } from '../services/geminiService';
import type { AnalysisResult, OptimizationResult } from '../types';
import { PROGRAMMING_LANGUAGES } from '../constants';
import { Spinner } from './shared/Spinner';
import { LeafIcon } from './icons/LeafIcon';
import { CodeIcon } from './icons/CodeIcon';

const CodeAnalyzer: React.FC = () => {
  const [code, setCode] = useState<string>('// Paste your code here to analyze its carbon footprint\n\nfunction fibonacci(n) {\n  if (n <= 1) return n;\n  return fibonacci(n - 1) + fibonacci(n - 2);\n}');
  const [language, setLanguage] = useState<string>('JavaScript');
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [optimization, setOptimization] = useState<OptimizationResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = useCallback(async () => {
    if (!code.trim()) {
      setError('Please enter some code to analyze.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setAnalysis(null);
    setOptimization(null);

    const result = await analyzeCode(code, language);
    if (result) {
      setAnalysis(result);
    } else {
      setError('Failed to analyze the code. Please try again.');
    }
    setIsLoading(false);
  }, [code, language]);

  const handleOptimize = useCallback(async () => {
    if (!code.trim()) {
      setError('Please enter some code to optimize.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setOptimization(null);

    const result = await optimizeCode(code, language);
    if (result) {
      setOptimization(result);
    } else {
      setError('Failed to optimize the code. Please try again.');
    }
    setIsLoading(false);
  }, [code, language]);

  return (
    <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Input Section */}
      <div className="bg-gray-800 p-6 rounded-lg shadow-xl">
        <h2 className="text-2xl font-bold mb-4 text-green-400 flex items-center"><CodeIcon /> <span className="ml-2">Code Input</span></h2>
        <div className="mb-4">
          <label htmlFor="language-select" className="block text-sm font-medium text-gray-300 mb-1">
            Language
          </label>
          <select
            id="language-select"
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            {PROGRAMMING_LANGUAGES.map((lang) => (
              <option key={lang} value={lang}>
                {lang}
              </option>
            ))}
          </select>
        </div>
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="Enter your code here..."
          className="w-full h-80 bg-gray-900 text-gray-200 font-mono p-4 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 resize-y"
        />
        <div className="mt-4 flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
          <button
            onClick={handleAnalyze}
            disabled={isLoading}
            className="flex-1 inline-flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-green-500 disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors"
          >
            {isLoading ? <Spinner /> : 'Analyze Footprint'}
          </button>
          <button
            onClick={handleOptimize}
            disabled={isLoading}
            className="flex-1 inline-flex justify-center items-center px-6 py-3 border border-green-500 text-base font-medium rounded-md shadow-sm text-green-400 bg-transparent hover:bg-green-500 hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-green-500 disabled:border-gray-500 disabled:text-gray-400 disabled:cursor-not-allowed transition-colors"
          >
            {isLoading ? <Spinner /> : 'Suggest Greener Code'}
          </button>
        </div>
        {error && <p className="mt-4 text-red-400">{error}</p>}
      </div>

      {/* Output Section */}
      <div className="bg-gray-800 p-6 rounded-lg shadow-xl space-y-6">
        <h2 className="text-2xl font-bold mb-4 text-green-400 flex items-center"><LeafIcon /> <span className="ml-2">Evaluation Results</span></h2>
        {isLoading && !analysis && !optimization && (
            <div className="flex justify-center items-center h-full">
                <div className="text-center">
                    <Spinner />
                    <p className="mt-2 text-gray-400">Evaluating your code...</p>
                </div>
            </div>
        )}
        {!isLoading && !analysis && !optimization && (
          <div className="text-center text-gray-400 py-16">
            <p>Your analysis results will appear here.</p>
          </div>
        )}
        {analysis && (
          <div className="bg-gray-700 p-4 rounded-lg animate-fade-in">
            <h3 className="text-lg font-semibold text-white mb-2">Carbon Footprint Analysis</h3>
            <p className="text-3xl font-bold text-green-400">{analysis.co2e.toFixed(4)} g CO2e</p>
            <p className="mt-2 text-gray-300">{analysis.explanation}</p>
          </div>
        )}
        {optimization && (
          <div className="bg-gray-700 p-4 rounded-lg animate-fade-in">
            <h3 className="text-lg font-semibold text-white mb-2">Optimized Code Suggestion</h3>
            <pre className="bg-gray-900 text-gray-200 font-mono p-3 my-2 rounded-md overflow-x-auto"><code>{optimization.optimizedCode}</code></pre>
            <p className="mt-2 text-gray-300">{optimization.explanation}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CodeAnalyzer;
