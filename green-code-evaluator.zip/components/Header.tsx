
import React from 'react';
import type { Tab } from '../types';
import { LeafIcon } from './icons/LeafIcon';
import { CodeIcon } from './icons/CodeIcon';
import { BrainIcon } from './icons/BrainIcon';

interface HeaderProps {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
}

const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab }) => {
  const navItems: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'analyze', label: 'Analyzer', icon: <CodeIcon /> },
    { id: 'learn', label: 'Learn', icon: <LeafIcon /> },
    { id: 'quiz', label: 'Quiz', icon: <BrainIcon /> },
  ];

  return (
    <header className="bg-gray-800 shadow-lg">
      <div className="container mx-auto px-4 sm:px-6 md:px-8 flex justify-between items-center py-4">
        <div className="flex items-center space-x-3">
          <LeafIcon className="h-8 w-8 text-green-400" />
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Green Code Evaluator
          </h1>
        </div>
        <nav className="flex space-x-2 sm:space-x-4">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center space-x-2 px-3 py-2 text-sm sm:text-base font-medium rounded-md transition-all duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-green-500 ${
                activeTab === item.id
                  ? 'bg-green-600 text-white shadow-md'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              {item.icon}
              <span className="hidden sm:inline">{item.label}</span>
            </button>
          ))}
        </nav>
      </div>
    </header>
  );
};

export default Header;
